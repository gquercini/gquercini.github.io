import json
import random 

languages = ["it", "en", "de", "fr", "es", "el"]

with open("./movies.json") as f:
    movies_data = json.load(f)

for m in movies_data:
    m["languages"] = random.sample(languages, k=random.randint(0, len(languages)))
    m.pop("summary")
    
with open("./movies_lang.json", "w") as f:
    json.dump(movies_data, f)