'''
client.py
Implementation of the client-side of ...
'''

import argparse

# adapted from https://github.com/pricheal/python-client-server/blob/master/client.py

import socket
import threading
import sys
import json
import struct
import utils

def send(socket, signal):
    while signal:
        next_message = input(">> ")
        if next_message == "#quit":
            msg = utils.prepare_quit_message()
            utils.send_msg(msg, socket)
            signal = False
        else:    
            msg = utils.prepare_chat_message(next_message)
            utils.send_msg(msg, socket)

def receive(socket, signal):
    while signal:
        message = utils.recv_msg(socket)
        if message:
            if message["type"] == "WELCOME":
                print(message["content"])
                sendThread = threading.Thread(target = send, args = (socket, True))
                sendThread.start()
            elif message["type"] == "CHAT":
                print(message["content"])
                print(">> ", end='', flush=True)
            elif message["type"] == "BYE":
                print(message["content"])
                signal = False
                break
        else:
            print("You have been disconnected from the server")
            signal = False
            break

if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument("server_host", help="The host where the server is running")
    parser.add_argument("server_port", \
        help="The port on which the server is listening", type=int)
    args = parser.parse_args()
    server_host = args.server_host
    server_port = args.server_port

    print(f"Attempting to connect to {server_host} at {server_port}")
    #Attempt connection to server
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((server_host, server_port))
    except Exception as e:
        print("Could not connect to the chat")
        print(e)
        sys.exit(0)

    print("Write your name and start to chat: ", end='')
    username = input()
    # Send hello to the server.
    hello_message = utils.prepare_hello_message(username)
    utils.send_msg(hello_message, sock)

    #Create new thread to wait for data
    receiveThread = threading.Thread(target = receive, args = (sock, True))
    receiveThread.start()
    