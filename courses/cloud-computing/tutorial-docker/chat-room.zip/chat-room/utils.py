import json
import struct

'''
Utility functions
'''

'''
Send a message over the given socket.
'''
def send_msg(message, sock):
    # Serialize the message as a json and encodes it.
    message = json.dumps(message).encode('utf-8')
    # Prefix the message with 4 bytes indicating the length.
    message = struct.pack('>L', len(message)) + message
    # Finally send the message
    sock.sendall(message)

'''
Receives a message on a given socket.
Source: https://stackoverflow.com/questions/17667903/python-socket-receive-large-amount-of-data
'''
def recv_msg(sock):
    # Read message length and unpack it into an integer
    raw_msglen = recvall(sock, 4)
    if not raw_msglen:
        return None
    msglen = struct.unpack('>I', raw_msglen)[0]
    # Read the message data
    msg = recvall(sock, msglen)
    return json.loads(msg.decode('utf-8'))

'''
Reveives n bytes from the given socket
'''
def recvall(sock, n):
    data = bytearray()
    while len(data) < n:
        packet = sock.recv(n - len(data))
        if not packet:
            return None
        data.extend(packet)
    return data

def prepare_hello_message(name):
    return {"type": "HELLO", "name": name}

def prepare_welcome_message(message):
    return {"type": "WELCOME", "content": message}

def prepare_bye_message(message):
    return {"type": "BYE", "content": message}

def prepare_chat_message(message):
    return {"type": "CHAT", "content": message}

def prepare_quit_message():
    return {"type": "QUIT"}